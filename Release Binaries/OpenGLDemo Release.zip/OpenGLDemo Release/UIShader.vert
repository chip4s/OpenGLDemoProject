#version 430 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec2 aTexCoord;


out vec2 texCoord;
uniform mat4 m;

void main()
{
	gl_Position = m * vec4(aPos, 1.0f);
	texCoord = aTexCoord;
}